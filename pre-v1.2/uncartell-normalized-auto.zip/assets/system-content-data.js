(()=>{
  const VALID_MODES=new Set(['local','auto','supabase']);
  const VALID_LOCALES=new Set(['ca','es','it']);
  const configured=window.UNCARTELL_FEATURES?.systemContentSource||localStorage.getItem('uncartell-system-content-source')||'auto';
  const mode=VALID_MODES.has(configured)?configured:'local';
  const locale=value=>VALID_LOCALES.has(value)?value:'ca';
  const query=async(table,columns)=>{
    const supabase=window.UncartellPlatform?.getSupabase?.();
    if(!supabase)throw new Error('Supabase is not available');
    const {data,error}=await supabase.from(table).select(columns);
    if(error)throw error;
    return data||[];
  };
  async function loadPosterCatalog(requestedLocale){
    if(mode==='local')return null;
    const activeLocale=locale(requestedLocale);
    try{
      const [parents,translations,terms,termTranslations]=await Promise.all([
        query('poster_templates','id,icon_key,custom_svg,primary_color,secondary_color,category_id,subcategory_id,required_plan,configuration,sort_order,is_featured,is_active'),
        query('poster_template_translations','template_id,locale,title,subtitle,status'),
        query('taxonomy_terms','id,kind,sort_order,is_active'),
        query('taxonomy_term_translations','term_id,locale,label,status')
      ]);
      const copy=new Map(translations.filter(row=>row.locale===activeLocale&&row.status==='published').map(row=>[row.template_id,row]));
      const labels=new Map(termTranslations.filter(row=>row.locale===activeLocale&&row.status==='published').map(row=>[row.term_id,row.label]));
      const validTerms=new Set(terms.filter(row=>row.is_active).map(row=>row.id));
      return parents.filter(row=>row.is_active&&copy.has(row.id)&&validTerms.has(row.category_id)&&validTerms.has(row.subcategory_id)&&labels.has(row.category_id)&&labels.has(row.subcategory_id)).map(row=>({
        id:row.id,icon:row.icon_key,customSvg:row.custom_svg,color:row.primary_color,secondary:row.secondary_color,
        category:labels.get(row.category_id),subcategory:labels.get(row.subcategory_id),title:copy.get(row.id).title,
        subtitle:copy.get(row.id).subtitle,requiredPlan:row.required_plan,order:row.sort_order,featured:row.is_featured,
        active:row.is_active,[`category${activeLocale[0].toUpperCase()+activeLocale.slice(1)}`]:labels.get(row.category_id),
        [`subcategory${activeLocale[0].toUpperCase()+activeLocale.slice(1)}`]:labels.get(row.subcategory_id),
        [`title${activeLocale[0].toUpperCase()+activeLocale.slice(1)}`]:copy.get(row.id).title,
        [`subtitle${activeLocale[0].toUpperCase()+activeLocale.slice(1)}`]:copy.get(row.id).subtitle,...(row.configuration||{})
      })).sort((a,b)=>a.order-b.order);
    }catch(error){if(mode==='auto'){console.warn('System content fallback: posters',error);return null}throw error}
  }
  async function loadEditorTemplates(toolType,requestedLocale){
    if(mode==='local')return null;
    const activeLocale=locale(requestedLocale);
    try{
      const [parents,translations]=await Promise.all([
        query('editor_templates','id,tool_type,format_id,payload,version,sort_order,is_published,is_active,required_plan,metadata'),
        query('editor_template_translations','template_id,locale,name,description,payload,status')
      ]);
      const copy=new Map(translations.filter(row=>row.locale===activeLocale&&row.status==='published').map(row=>[row.template_id,row]));
      return parents.filter(row=>row.tool_type===toolType&&row.is_active&&row.is_published&&copy.has(row.id)).map(row=>{
        const localized=copy.get(row.id);
        return {...row,name:localized.name,detail:localized.description,
          payload:localized.payload?.document?localized.payload:(row.payload||{}),blank:false};
      }).sort((a,b)=>a.sort_order-b.sort_order);
    }catch(error){if(mode==='auto'){console.warn('System content fallback: editor templates',error);return null}throw error}
  }
  window.UncartellSystemContent=Object.freeze({mode,loadPosterCatalog,loadEditorTemplates});
})();
